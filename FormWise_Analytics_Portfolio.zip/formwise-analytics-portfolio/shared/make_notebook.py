"""Convert a percent-format script (cells split by '# %%') into an executed Jupyter notebook.

Usage: python shared/make_notebook.py <project_dir>/analysis.py
Writes <project_dir>/analysis.ipynb with outputs.
"""
import sys, os, re
import nbformat
from nbconvert.preprocessors import ExecutePreprocessor

src = sys.argv[1]
text = open(src).read()
cells = []
for chunk in re.split(r"^# %%", text, flags=re.M)[1:]:
    header, _, body = chunk.partition("\n")
    if header.strip().startswith("[markdown]"):
        md = "\n".join(l[2:] if l.startswith("# ") else l.lstrip("#") for l in body.strip().splitlines())
        cells.append(nbformat.v4.new_markdown_cell(md))
    else:
        cells.append(nbformat.v4.new_code_cell(body.strip()))
nb = nbformat.v4.new_notebook(cells=cells)
nb.metadata["kernelspec"] = {"name": "python3", "display_name": "Python 3", "language": "python"}
proj = os.path.dirname(os.path.abspath(src))
ExecutePreprocessor(timeout=900, kernel_name="python3").preprocess(nb, {"metadata": {"path": proj}})
out = os.path.splitext(src)[0] + ".ipynb"
nbformat.write(nb, out)
print("wrote", out)
