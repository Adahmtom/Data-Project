"""Shared helpers for the FormWise analytics portfolio."""
import os, sqlite3
import pandas as pd
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB = os.path.join(ROOT, "data", "formwise.db")

PALETTE = {"primary": "#2B5C8A", "accent": "#D9822B", "muted": "#9AA5B1", "good": "#2E8B57", "bad": "#C0392B"}


def connect():
    if not os.path.exists(DB):
        raise FileNotFoundError("Run `python data/generate_data.py` first to build data/formwise.db")
    return sqlite3.connect(DB)


def q(sql, con=None, **params):
    """Run SQL (a string or a path to a .sql file) and return a DataFrame."""
    if sql.endswith(".sql") and os.path.exists(sql):
        sql = open(sql).read()
    own = con is None
    con = con or connect()
    try:
        return pd.read_sql_query(sql, con, params=params or None)
    finally:
        if own:
            con.close()


def style():
    plt.rcParams.update({
        "figure.figsize": (9, 4.5), "figure.dpi": 110, "axes.spines.top": False, "axes.spines.right": False,
        "axes.grid": True, "grid.alpha": 0.25, "axes.titleweight": "bold", "axes.titlesize": 12,
        "font.size": 10,
    })


def save(fig, name):
    os.makedirs("figures", exist_ok=True)
    fig.savefig(os.path.join("figures", name), bbox_inches="tight", dpi=140)
