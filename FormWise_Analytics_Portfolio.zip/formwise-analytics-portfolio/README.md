# Product Analytics Portfolio: FormWise

Five end-to-end analytics projects for **FormWise**, a *fictional* online legal-document subscription service.
All data is **simulated** by `data/generate_data.py`, a seeded and reproducible generator. Realistic problems are
built into it on purpose (device friction, a modest experiment effect, a mobile tracking bug, duplicate events) so
the analysis has real findings to uncover.

| # | Project | Business question | Methods |
|---|---------|-------------------|---------|
| 1 | [Paywall A/B test](01_ab_test_paywall/) | Should we ship the redesigned paywall? | Power analysis, SRM check, two-proportion z-test, confidence intervals, bootstrap, Holm correction |
| 2 | [SQL funnel & friction analysis](02_sql_funnel_analysis/) | Where are we losing users, and which fix is worth most? | SQL (CTEs, joins, conditional aggregation, window functions), chi-square tests, opportunity sizing |
| 3 | [Renewals, retention & segmentation](03_renewal_retention_segmentation/) | Who renews, what predicts it, which segments matter? | Cohort retention, logistic regression, k-means segmentation, assumption testing |
| 4 | [Tracking & attribution audit](04_tracking_attribution_audit/) | Can we trust our purchase tracking, and who gets credit? | Event-vs-billing reconciliation, data-quality checks, multi-touch attribution, tracking plan |
| 5 | [Automated KPI report](05_kpi_automated_report/) | Can stakeholders self-serve monthly KPIs? | Python + SQL pipeline to a formula-driven Excel workbook (SUMIFS, INDEX/MATCH, charts, data-quality flags) |

The projects build on each other. Project 4's tracking audit explains why Projects 1–3 measure purchases from billing
data. Project 3 overturns an assumption behind Project 1's guardrail metric. Project 2 points the next experiment at
the mobile form.

## Run it
```bash
pip install -r requirements.txt
python data/generate_data.py                       # builds data/formwise.db (~60 MB, about 15 s)
jupyter notebook                                   # open any analysis.ipynb
python 05_kpi_automated_report/build_report.py --month 2026-06
```
Each project has an `analysis.py` (readable source in percent-cell format) and an executed `analysis.ipynb`.
To rebuild a notebook: `python shared/make_notebook.py <project>/analysis.py`.

## Tools
SQL (SQLite) · Python (pandas, NumPy, SciPy, statsmodels, scikit-learn, Matplotlib) · Excel (openpyxl) · Jupyter.
Developed in VS Code with an AI coding agent for scaffolding, refactoring and debugging. Analytical design,
validation and conclusions are my own.
