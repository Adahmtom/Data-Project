# 5 · Automated Monthly KPI Report

**Goal:** replace a manual monthly report with a reproducible pipeline that stakeholders can self-serve.

`build_report.py --month YYYY-MM` pulls metrics with SQL and writes an Excel workbook where **every KPI is a live
formula** driven by one input cell (the report month, chosen from a dropdown):
- **KPI Summary:** this month vs prior month vs same month last year, with conditional formatting and a channel ×
  device conversion grid built with `SUMIFS`, including a built-in reconciliation check.
- **Monthly:** 18-month trend with conversion and revenue charts.
- **Data Quality:** flags months where purchase tracking disagrees with billing beyond a set tolerance.
- **Data:** the raw extract the formulas read from.

It also writes `summary_YYYY-MM.md`, a plain-language note of the month's biggest changes, which warns readers to
check whether a channel move is noise before acting on it.

**Files:** `build_report.py` · `output/FormWise_KPI_Report_2026-06.xlsx` · `output/summary_2026-06.md`
