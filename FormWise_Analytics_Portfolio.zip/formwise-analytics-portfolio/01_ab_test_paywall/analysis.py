# %% [markdown]
# # Project 1 — Paywall Redesign A/B Test (`paywall_v2`)
#
# **Company:** FormWise, a *fictional* online legal-document subscription service (simulated data).
#
# **Business question.** Users who finish filling in a document hit a paywall before they can download it.
# The product team redesigned the paywall to show a full preview of the user's completed document and a clearer
# monthly-vs-annual plan comparison. Does the new paywall convert more users into paying subscribers, and should we ship it?
#
# **Experiment design (agreed with the Product Owner before launch)**
#
# | Item | Decision |
# |---|---|
# | Unit of randomization | Visitor (50/50 split at first visit) |
# | Population analysed | *Triggered* visitors only: those who actually saw the paywall |
# | Primary metric | Paywall → purchase conversion rate |
# | Secondary metric | Revenue per paywall viewer (first payment) |
# | Guardrail | Annual-plan share must not drop (annual plans retain better) |
# | Significance level / power | α = 0.05 two-sided, 80% power |
# | Minimum detectable effect | +15% relative lift on a ~17% baseline |
# | Run dates | 6 Apr – 14 Jun 2026 (ten full weeks, set by the power analysis below) |
#
# **Assumptions & limitations** recorded up front: conversion is measured from the **billing system** (payments), not
# from front-end analytics events, because Project 4 found that purchase events from mobile app 3.2.0 were partially
# missing during this period. Novelty effects cannot be fully ruled out.

# %%
import sys; sys.path.append("..")
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from scipy import stats
from statsmodels.stats.power import NormalIndPower
from statsmodels.stats.proportion import proportion_effectsize, proportions_ztest, confint_proportions_2indep
from statsmodels.stats.multitest import multipletests
from shared.helpers import q, style, save, PALETTE
style()

# %% [markdown]
# ## 1. Pre-test: sample size and duration
# Baseline paywall conversion comes from the eight weeks *before* the test.

# %%
baseline = q("""
WITH pv AS (
  SELECT DISTINCT e.visitor_id FROM events e
  WHERE e.event_name = 'paywall_view'
    AND e.event_ts >= '2026-02-09' AND e.event_ts < '2026-04-06')
SELECT COUNT(*) AS paywall_viewers,
       SUM(CASE WHEN s.user_id IS NOT NULL THEN 1 ELSE 0 END) AS purchasers
FROM pv LEFT JOIN subscriptions s ON s.visitor_id = pv.visitor_id
""")
p0 = baseline.purchasers[0] / baseline.paywall_viewers[0]
weekly_viewers = baseline.paywall_viewers[0] / 8
p1 = p0 * 1.15
n_per_arm = NormalIndPower().solve_power(proportion_effectsize(p1, p0), alpha=0.05, power=0.8, ratio=1)
print(f"Baseline conversion: {p0:.2%}   target: {p1:.2%}")
print(f"Required sample: {n_per_arm:,.0f} paywall viewers per arm")
print(f"Expected paywall viewers per week: {weekly_viewers:,.0f}  ->  {2*n_per_arm/weekly_viewers:.1f} weeks needed")

# %% [markdown]
# The power analysis says roughly ten weeks of traffic are needed, so the test was scheduled for ten full weeks and
# analysed only at the end, rather than stopped at the first significant-looking result (avoiding the "peeking" problem).
#
# ## 2. Sanity checks
# ### Sample ratio mismatch (SRM)
# If the 50/50 split is broken (for example, a redirect bug dropping one arm), every downstream result is suspect.

# %%
assign = q("SELECT variant, COUNT(*) AS n FROM experiment_assignments GROUP BY variant")
chi2, p_srm = stats.chisquare(assign.n)
print(assign.to_string(index=False))
print(f"SRM chi-square p-value = {p_srm:.3f}  ->  {'OK' if p_srm > 0.01 else 'INVESTIGATE'}")

# %% [markdown]
# ### Was exposure to the paywall balanced?
# The redesign only changes the paywall itself, so the share of visitors who *reach* it should be the same in both
# arms. A difference here would mean the triggered populations are not comparable.

# %%
df = q("""
SELECT a.visitor_id, a.variant, v.device, v.channel,
       MAX(CASE WHEN e.event_name = 'paywall_view' THEN 1 ELSE 0 END) AS saw_paywall,
       s.plan, s.user_id IS NOT NULL AS purchased,
       COALESCE(p.amount, 0) AS first_payment
FROM experiment_assignments a
JOIN visitors v ON v.visitor_id = a.visitor_id
LEFT JOIN events e ON e.visitor_id = a.visitor_id AND e.event_name = 'paywall_view'
LEFT JOIN subscriptions s ON s.visitor_id = a.visitor_id
LEFT JOIN payments p ON p.user_id = s.user_id AND p.payment_type = 'new'
GROUP BY a.visitor_id
""")
reach = df.groupby("variant").saw_paywall.agg(["sum", "count", "mean"])
z, p_reach = proportions_ztest(reach["sum"], reach["count"])
print(reach.rename(columns={"sum": "saw_paywall", "count": "assigned", "mean": "reach_rate"}).round(4))
print(f"Difference in reach rate p-value = {p_reach:.3f}")

# %% [markdown]
# Both checks pass. Analysis continues on the triggered population.
#
# ## 3. Primary metric: paywall → purchase conversion

# %%
t = df[df.saw_paywall == 1]
res = t.groupby("variant").purchased.agg(purchases="sum", viewers="count")
res["conversion"] = res.purchases / res.viewers
c, tr = res.loc["control"], res.loc["treatment"]
z, p_val = proportions_ztest([tr.purchases, c.purchases], [tr.viewers, c.viewers])
lo, hi = confint_proportions_2indep(tr.purchases, tr.viewers, c.purchases, c.viewers, method="newcomb")
rel = tr.conversion / c.conversion - 1
# bootstrap CI for relative lift
rng = np.random.default_rng(0)
bc = rng.binomial(int(c.viewers), c.conversion, 20000) / c.viewers
bt = rng.binomial(int(tr.viewers), tr.conversion, 20000) / tr.viewers
rel_lo, rel_hi = np.percentile(bt / bc - 1, [2.5, 97.5])
print(res.round(4).to_string())
print(f"\nAbsolute lift: {tr.conversion - c.conversion:+.2%}  (95% CI {lo:+.2%} to {hi:+.2%})")
print(f"Relative lift: {rel:+.1%}  (95% CI {rel_lo:+.1%} to {rel_hi:+.1%})")
print(f"Two-proportion z-test p-value: {p_val:.4f}")

# %%
fig, ax = plt.subplots(figsize=(6.5, 4))
ci = [1.96 * np.sqrt(r.conversion * (1 - r.conversion) / r.viewers) for _, r in res.iterrows()]
ax.bar(["Control\n(current paywall)", "Treatment\n(preview + plan comparison)"], res.conversion, yerr=ci,
       color=[PALETTE["muted"], PALETTE["primary"]], capsize=6, width=0.55)
for i, v_ in enumerate(res.conversion):
    ax.text(i, v_ / 2, f"{v_:.1%}", ha="center", color="white", fontweight="bold", fontsize=12)
ax.set_ylabel("Paywall → purchase conversion"); ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x:.0%}"))
ax.set_title("paywall_v2: conversion by variant (95% CI)")
save(fig, "01_conversion_by_variant.png"); plt.show()

# %% [markdown]
# ## 4. Secondary metric and guardrail

# %%
rev = t.groupby("variant").first_payment.agg(["mean", "count"])
tt = stats.ttest_ind(t[t.variant == "treatment"].first_payment, t[t.variant == "control"].first_payment, equal_var=False)
annual = t[t.purchased == 1].groupby("variant").plan.apply(lambda s: (s == "annual").mean())
za, p_ann = proportions_ztest(
    [(t[(t.variant == g) & (t.purchased == 1)].plan == "annual").sum() for g in ["treatment", "control"]],
    [t[(t.variant == g) & (t.purchased == 1)].shape[0] for g in ["treatment", "control"]])
print("Revenue per paywall viewer (first payment):")
print(rev["mean"].map("${:.2f}".format).to_string())
print(f"Welch t-test p-value: {tt.pvalue:.4f}")
print("\nGuardrail: annual-plan share among purchasers")
print(annual.map("{:.1%}".format).to_string())
print(f"Difference p-value: {p_ann:.3f}  ->  {'guardrail held' if annual['treatment'] >= annual['control'] - 0.03 else 'guardrail breached'}")

# %% [markdown]
# ## 5. Where does the effect come from? (exploratory)
# Segment cuts were **not** the primary hypothesis, so p-values are adjusted for multiple comparisons (Holm) and the
# results are treated as directions for follow-up rather than conclusions.

# %%
rows = []
for dev, g in t.groupby("device"):
    r = g.groupby("variant").purchased.agg(["sum", "count"])
    _, p = proportions_ztest(r.loc[["treatment", "control"], "sum"], r.loc[["treatment", "control"], "count"])
    cr = r["sum"] / r["count"]
    rows.append({"device": dev, "viewers": int(r["count"].sum()), "control": cr["control"],
                 "treatment": cr["treatment"], "relative_lift": cr["treatment"] / cr["control"] - 1, "p_raw": p})
seg = pd.DataFrame(rows)
seg["p_holm"] = multipletests(seg.p_raw, method="holm")[1]
print(seg.round(4).to_string(index=False))

# %%
fig, ax = plt.subplots(figsize=(7, 3.8))
ax.barh(seg.device, seg.relative_lift, color=[PALETTE["primary"] if p < 0.05 else PALETTE["muted"] for p in seg.p_holm])
for i, (l, p) in enumerate(zip(seg.relative_lift, seg.p_holm)):
    ax.text(l + 0.005, i, f"{l:+.0%}  (Holm p={p:.3f})", va="center")
ax.axvline(0, color="black", lw=0.8)
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"{x:+.0%}"))
ax.set_xlim(min(0, seg.relative_lift.min()) - 0.02, seg.relative_lift.max() + 0.2)
ax.set_title("Relative conversion lift by device (exploratory)")
save(fig, "01_lift_by_device.png"); plt.show()

# %% [markdown]
# ### What would it take to confirm the mobile result?

# %%
m = seg.set_index("device").loc["mobile"]
n_mobile = NormalIndPower().solve_power(proportion_effectsize(m.control * 1.20, m.control), alpha=0.05, power=0.8)
mobile_weekly = t[t.device == "mobile"].shape[0] / 10
print(f"Mobile baseline {m.control:.1%}; detecting a +20% relative lift needs {n_mobile:,.0f} mobile paywall viewers per arm")
print(f"At ~{mobile_weekly:,.0f} mobile paywall viewers/week (both arms), that is about {2*n_mobile/mobile_weekly:.0f} weeks")

# %% [markdown]
# ## 6. Recommendation
# The figures quoted below are the printed outputs above.
#
# **Overall, the test did not reach significance.** Conversion rose from 19.6% to 20.9% (+6.9% relative), but the
# 95% confidence interval runs from about −0.5 to +3.2 percentage points and p = 0.16. The true overall effect is
# smaller than the +15% the test was powered to detect, so "no significant difference" here means *we cannot tell*,
# not *it does not work*. Revenue per viewer and annual-plan share moved in the right direction, but neither is
# significant on its own.
#
# **Mobile is a different story.** Mobile conversion rose from 13.1% to 17.0% (+30% relative). That result survives a
# Holm correction for testing three device segments (adjusted p = 0.043), and it has a plausible mechanism: on a
# small screen, seeing the finished document is stronger reassurance than on desktop, where users can already see
# most of the form. Desktop shows essentially no change.
#
# **Recommendation to the Product Owner:**
# 1. **Do not claim an overall win.** Reporting the +6.9% as a result would overstate the evidence.
# 2. **Lay out the mobile decision as a trade-off, not a certainty.** A properly powered confirmatory test on mobile
#    alone would take about 28 weeks at current traffic. Because no metric moved in a harmful direction, a reasonable
#    alternative is to ship the redesign to mobile now and keep a 10% holdout to keep measuring. That accepts more
#    uncertainty in exchange for capturing the likely gain sooner. This is the Product Owner's call; my job is to make
#    the cost of each option clear.
# 3. **Keep the current paywall on desktop.** There is no evidence the redesign helps there, and simpler is cheaper to
#    maintain.
# 4. **Prioritize the mobile form step next.** Project 2 shows the form step loses more mobile users than the
#    paywall does, so it is the larger opportunity.
#
# **Measurement note:** conversions come from billing data. Front-end purchase events from mobile app 3.2.0 were
# partially missing during the test (Project 4); using them would have undercounted mobile purchases and could have
# hidden the very effect we found.
#
# **Postscript (after Project 3).** The annual-plan-share guardrail turned out to rest on a wrong assumption: at current
# prices, a new monthly subscriber is worth about twice as much in first-year revenue as an annual one. Future paywall
# tests should use **expected 12-month revenue per paywall viewer** as the guardrail instead.
