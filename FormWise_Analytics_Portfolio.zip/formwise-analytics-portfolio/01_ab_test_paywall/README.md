# 1 · Paywall Redesign A/B Test

**Question:** Does a paywall that previews the user's finished document convert more visitors into subscribers?

**Design:** visitor-level 50/50 split; triggered analysis on paywall viewers; primary metric paywall → purchase
conversion; α = 0.05, 80% power, MDE +15% relative. The power analysis set the run length at 10 weeks.

**Findings**
- Sanity checks passed (no sample ratio mismatch; equal paywall exposure in both arms).
- **Overall: not significant.** Conversion 19.6% → 20.9% (+6.9% relative, 95% CI −2.6% to +17.4%, p = 0.16).
  The test can't distinguish a small real effect from zero.
- **Mobile: +30% relative lift** (13.1% → 17.0%), significant after Holm correction for three segments
  (adjusted p = 0.043). Desktop shows no change.
- **Recommendation:** don't claim an overall win. Present the mobile decision as a trade-off: a confirmatory mobile
  test would take ~28 weeks, versus shipping to mobile with a 10% holdout. Keep the current desktop paywall.

**Files:** `analysis.ipynb` · `analysis.py` · `figures/`
