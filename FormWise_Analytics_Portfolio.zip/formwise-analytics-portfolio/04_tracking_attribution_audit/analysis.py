# %% [markdown]
# # Project 4 — Tracking Quality & Attribution Audit
#
# **Company:** FormWise, a *fictional* online legal-document subscription service (simulated data).
#
# **Trigger.** The marketing channel report, which joins front-end `purchase` events to users and acquisition
# channels, showed mobile purchases falling in spring 2026, while finance reported steady revenue. Which number is
# right, and what else is the tracking getting wrong?
#
# **Scope**
# 1. Reconcile front-end purchase events against the billing system (source of truth).
# 2. Find and quantify each data-quality issue.
# 3. Show how much channel credit changes under different attribution models.
# 4. Propose a tracking plan with automated validation checks.

# %%
import sys; sys.path.append("..")
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from shared.helpers import q, connect, style, save, PALETTE
style()
con = connect()

# %% [markdown]
# ## 1. Reconciliation: events vs billing, by week and platform

# %%
recon = q("""
WITH ev AS (
  SELECT strftime('%Y-%W', event_ts) AS week,
         CASE WHEN app_version = 'web' THEN 'web' ELSE 'mobile_app' END AS platform,
         COUNT(*) AS purchase_events,
         COUNT(user_id) AS attributable_events      -- events that can be joined to a user / channel
  FROM events WHERE event_name = 'purchase' GROUP BY week, platform
),
bill AS (
  SELECT strftime('%Y-%W', p.payment_ts) AS week,
         CASE WHEN v.device = 'mobile' THEN 'mobile_app' ELSE 'web' END AS platform,
         COUNT(*) AS billed_new_subs
  FROM payments p
  JOIN subscriptions s ON s.user_id = p.user_id
  JOIN visitors v ON v.visitor_id = s.visitor_id
  WHERE p.payment_type = 'new' GROUP BY week, platform
)
SELECT b.week, b.platform, b.billed_new_subs, COALESCE(e.purchase_events, 0) AS purchase_events,
       COALESCE(e.attributable_events, 0) AS attributable_events
FROM bill b LEFT JOIN ev e ON e.week = b.week AND e.platform = b.platform
ORDER BY b.week, b.platform
""", con)
recon["events_vs_billing"] = recon.attributable_events / recon.billed_new_subs - 1
print(recon.groupby("platform")[["billed_new_subs", "purchase_events", "attributable_events"]].sum().to_string())

# %%
fig, ax = plt.subplots(figsize=(10, 4.2))
for plat, col in [("web", PALETTE["primary"]), ("mobile_app", PALETTE["accent"])]:
    r = recon[recon.platform == plat]
    ax.plot(r.week, r.events_vs_billing.rolling(3, center=True).mean(), color=col, lw=2, label=plat)
ax.axhline(0, color="black", lw=0.8)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:+.0%}"))
ticks = recon.week.unique()[::8]; ax.set_xticks(ticks, ticks, rotation=45)
ax.set_title("Attributable purchase events vs billed subscriptions (3-week avg); 0% = match")
ax.legend(); save(fig, "04_reconciliation.png"); plt.show()

# %% [markdown]
# **Mobile** tracks billing closely except for a sharp dip in spring 2026, which explains the falling channel report.
# **Web** totals look almost perfect, but that turns out to be two errors cancelling out (section 2): duplicate events
# inflate the count while lost events deflate it. A total that matches doesn't prove the tracking is right. The next
# step is to break the issues down by type.
#
# ## 2. Data-quality issues, one by one

# %%
dq = q("""
SELECT app_version,
       COUNT(*)                                             AS purchase_events,
       SUM(user_id IS NULL)                                 AS missing_user_id,
       ROUND(1.0 * SUM(user_id IS NULL) / COUNT(*), 4)      AS missing_user_id_rate,
       COUNT(*) - COUNT(DISTINCT COALESCE(order_id, event_id)) AS duplicate_order_events
FROM events WHERE event_name = 'purchase'
GROUP BY app_version ORDER BY app_version
""", con)
print(dq.to_string(index=False))

# %%
# Issue A: duplicates — same order_id fired more than once within seconds (client retries)
dups = q("""
SELECT order_id, COUNT(*) AS n,
       (julianday(MAX(event_ts)) - julianday(MIN(event_ts))) * 86400 AS seconds_apart
FROM events WHERE event_name = 'purchase' AND order_id IS NOT NULL
GROUP BY order_id HAVING COUNT(*) > 1
""", con)
# Issue C: billed orders with no purchase event at all (web only; app 3.2.0 losses are counted in Issue B)
missing = q("""
SELECT COUNT(*) AS billed_web_orders_without_event FROM subscriptions s
JOIN visitors v ON v.visitor_id = s.visitor_id
WHERE v.device <> 'mobile'
  AND NOT EXISTS (SELECT 1 FROM events e WHERE e.event_name = 'purchase' AND e.visitor_id = s.visitor_id)
""", con)
web_billed = recon[recon.platform == "web"].billed_new_subs.sum()
bug_rows = dq.set_index("app_version").loc["3.2.0"]
issues = pd.DataFrame([
    ["A. Duplicate purchase events", f"{len(dups):,} orders fired twice, median {dups.seconds_apart.median():.0f}s apart",
     "Inflates conversion; client retries on slow networks", "Deduplicate on order_id; make the event idempotent"],
    ["B. Missing user_id / order_id", f"{bug_rows.missing_user_id_rate:.0%} of app 3.2.0 purchase events",
     "Purchases can't be tied to users, channels or experiments", "Fixed in 3.2.1; add a required-field check to release QA"],
    ["C. Purchase event never fires", f"{missing.iloc[0,0]:,} web orders ({missing.iloc[0,0]/web_billed:.1%})",
     "Ad blockers or users closing the tab before the confirmation page loads", "Send the purchase event server-side from the billing webhook"],
], columns=["issue", "size", "impact", "fix"])
print(issues.to_string(index=False))

# %% [markdown]
# **What did the bug cost in reporting terms?** During the 3.2.0 window, an event-based dashboard under-reported
# mobile conversions, which is what triggered this audit:

# %%
w = q("""
SELECT
  (SELECT COUNT(*) FROM events WHERE event_name='purchase' AND app_version='3.2.0' AND user_id IS NOT NULL) AS attributable_events,
  (SELECT COUNT(*) FROM events WHERE event_name='purchase' AND app_version='3.2.0') AS all_events
""", con)
print(f"Mobile purchases visible to user-level reporting during 3.2.0: {w.attributable_events[0]:,} of {w.all_events[0]:,} "
      f"({w.attributable_events[0]/w.all_events[0]:.0%}).")
print("Any report joining purchases to users, channels or experiments undercounted mobile by that gap for 11 weeks,")
print("which overlapped the paywall_v2 experiment. This is why Projects 1-3 measure purchases from billing.")

# %% [markdown]
# ## 3. Attribution: who gets credit for a subscription?
# Each purchaser has 1–4 marketing touchpoints before their first visit. Four models are compared:
# **last touch** (current dashboard), **first touch**, **linear**, and **position-based** (40% first, 40% last, 20% spread
# across the middle).

# %%
touches = q("""
SELECT t.visitor_id, t.channel, t.touch_ts, p.amount
FROM marketing_touches t
JOIN subscriptions s ON s.visitor_id = t.visitor_id
JOIN payments p ON p.user_id = s.user_id AND p.payment_type = 'new'
ORDER BY t.visitor_id, t.touch_ts
""", con)
touches["pos"] = touches.groupby("visitor_id").cumcount()
touches["n"] = touches.groupby("visitor_id").visitor_id.transform("size")

def weights(model, pos, n):
    if model == "last_touch": return (pos == n - 1).astype(float)
    if model == "first_touch": return (pos == 0).astype(float)
    if model == "linear": return 1.0 / n
    w = np.where(n == 1, 1.0, np.where(n == 2, 0.5, np.where((pos == 0) | (pos == n - 1), 0.4, 0.2 / (n - 2).clip(lower=1))))
    return w
credit = {}
for m in ["last_touch", "first_touch", "linear", "position_based"]:
    credit[m] = (touches.amount * weights(m, touches.pos, touches.n)).groupby(touches.channel).sum()
credit = pd.DataFrame(credit)
share = credit / credit.sum()
share["change_vs_last_touch"] = share.position_based - share.last_touch
print((share * 100).round(1).sort_values("change_vs_last_touch").to_string())
print("\nRevenue check (each model sums to the same total):", credit.sum().round(0).unique())

# %%
fig, ax = plt.subplots(figsize=(9, 4.2))
sh = share.sort_values("last_touch")
y = np.arange(len(sh)); h = 0.38
ax.barh(y - h/2, sh.last_touch, h, color=PALETTE["muted"], label="last touch (current)")
ax.barh(y + h/2, sh.position_based, h, color=PALETTE["primary"], label="position-based")
ax.set_yticks(y, sh.index); ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.0%}")); ax.legend()
ax.set_title("Share of first-payment revenue credited to each channel")
save(fig, "04_attribution.png"); plt.show()

# %% [markdown]
# **Social is the most under-credited channel under last touch.** It often *starts* journeys that end with a search or
# direct visit, so last-touch reporting hands its credit to search. Budget decisions made on last-touch numbers
# would systematically under-invest in social. No single model is "true", so I'd report last touch alongside
# position-based and validate with a holdout test (pausing social in a few regions) before moving budget.
#
# ## 4. Proposed tracking plan and automated checks

# %%
plan = pd.DataFrame([
    ["template_start", "visitor_id, doc_type, device, app_version", "Once per visitor per template"],
    ["form_field_error (new)", "visitor_id, doc_type, field_name, error_type", "Pinpoints mobile form friction (Project 2)"],
    ["form_abandon (new)", "visitor_id, doc_type, last_field_completed", "Fires on exit before form_complete"],
    ["form_complete", "visitor_id, doc_type, minutes_on_form", "Once per visitor per template"],
    ["paywall_view", "visitor_id, experiment_id, variant", "Variant must be present during experiments"],
    ["purchase", "visitor_id, user_id, order_id, plan, amount", "Sent server-side from billing webhook; unique order_id"],
], columns=["event", "required properties", "rule"])
print(plan.to_string(index=False))

# %%
def validate_purchase_events(con, since):
    """Daily data-quality checks to run before dashboards refresh. Returns failed checks."""
    checks = {
        "duplicate order_id": """SELECT COUNT(*) FROM (SELECT order_id FROM events WHERE event_name='purchase'
                                  AND order_id IS NOT NULL AND event_ts >= :s GROUP BY order_id HAVING COUNT(*) > 1)""",
        "missing user_id": "SELECT COUNT(*) FROM events WHERE event_name='purchase' AND user_id IS NULL AND event_ts >= :s",
        "events vs billing gap > 3%": """SELECT ABS(1.0 * (SELECT COUNT(DISTINCT order_id) FROM events WHERE event_name='purchase' AND event_ts >= :s)
                                     / NULLIF((SELECT COUNT(*) FROM payments WHERE payment_type='new' AND payment_ts >= :s), 0) - 1) > 0.03""",
    }
    out = {name: con.execute(sql, {"s": since}).fetchone()[0] for name, sql in checks.items()}
    return {k: v for k, v in out.items() if v}

for start in ["2026-02-01", "2026-04-01", "2026-06-01"]:
    print(start, "->", validate_purchase_events(con, start) or "all checks passed")

# %% [markdown]
# Run daily, these checks would have flagged the app 3.2.0 bug within a day of release instead of weeks later.
# They also show duplicates are an ongoing issue, which the server-side purchase event fixes at the source.
#
# ## 5. Recommendations
# 1. **Make billing the source of truth for purchases** in every conversion report, experiment readout and channel
#    report; keep front-end events for behaviour *before* purchase.
# 2. **Move the purchase event server-side** (from the billing webhook) to remove duplicates and ad-blocker losses.
# 3. **Add the data-quality checks to the daily pipeline** and to mobile release QA.
# 4. **Report attribution with two models side by side**, and test social's real contribution with a regional holdout
#    before changing budget.

# %%
con.close()
