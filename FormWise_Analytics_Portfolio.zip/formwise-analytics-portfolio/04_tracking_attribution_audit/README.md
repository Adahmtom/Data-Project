# 4 · Tracking Quality & Attribution Audit

**Trigger:** the channel report showed mobile purchases falling while finance saw steady revenue.

**Methods:** weekly reconciliation of front-end purchase events against the billing system; data-quality checks
(duplicates, missing IDs, lost events); four attribution models (last, first, linear, position-based); a proposed
tracking plan; and an automated validation function.

**Findings**
- Mobile app 3.2.0 dropped `user_id` on **44%** of purchase events for 11 weeks, so channel and experiment reports
  undercounted mobile purchases.
- Web totals *looked* correct only because two errors cancelled out: duplicate events (client retries) and lost
  events (~3% of orders).
- Last-touch attribution gives social **7%** of revenue credit; position-based gives **14%**. Social starts journeys
  that search gets credit for.
- Daily automated checks would have caught the app bug within a day.

**Files:** `analysis.ipynb` · `analysis.py` · `figures/`
