# %% [markdown]
# # Project 3 — Subscription Renewals, Retention Cohorts & Customer Segmentation
#
# **Company:** FormWise, a *fictional* online legal-document subscription service (simulated data).
#
# **Business questions**
# 1. How well do monthly subscribers renew, and when do we lose them?
# 2. What early behaviour predicts renewal?
# 3. Which customer segments should the product and lifecycle teams target, and with what?
#
# **Data:** `subscriptions` and `payments` (billing system), observed up to 30 Sep 2026.
# **Key definition:** a monthly subscriber is *retained at month k* if they made a payment for month k.
# Cohorts are only measured for months that have fully elapsed, which avoids counting recent subscribers as churned
# just because their renewal date hasn't arrived yet (right-censoring).

# %%
import sys; sys.path.append("..")
import numpy as np, pandas as pd, matplotlib.pyplot as plt
import statsmodels.formula.api as smf
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from shared.helpers import q, connect, style, save, PALETTE
style()
con = connect()
AS_OF = pd.Timestamp("2026-09-30")

subs = q("""
SELECT s.user_id, s.plan, s.start_ts, s.end_ts, s.payments_made, s.docs_created_30d,
       v.device, v.channel, v.country, v.landing_doc_type
FROM subscriptions s JOIN visitors v ON v.visitor_id = s.visitor_id
""", con, )
subs["start_ts"] = pd.to_datetime(subs.start_ts); subs["end_ts"] = pd.to_datetime(subs.end_ts)
subs["cohort"] = subs.start_ts.dt.to_period("M")
print(subs.plan.value_counts().to_string())

# %% [markdown]
# ## 1. Monthly-plan retention cohorts

# %%
mon = subs[subs.plan == "monthly"].copy()
# months observable for each subscriber = full months between start and AS_OF
mon["months_observable"] = ((AS_OF.year - mon.start_ts.dt.year) * 12 + (AS_OF.month - mon.start_ts.dt.month)
                            - (AS_OF.day < mon.start_ts.dt.day)).clip(lower=0)
rows = []
for k in range(0, 13):
    elig = mon[mon.months_observable >= k]
    g = elig.groupby("cohort").apply(lambda d: (d.payments_made > k).mean(), include_groups=False)
    rows.append(g.rename(k))
cohort = pd.concat(rows, axis=1)
cohort = cohort.loc[:, cohort.columns >= 0]
print("Share of each monthly cohort still paying k months after signup (month 0 = 100% by definition):")
print((cohort.iloc[:, :7] * 100).round(0).to_string())

# %%
fig, ax = plt.subplots(figsize=(10, 5.2))
data = cohort.iloc[:, 1:13].values
im = ax.imshow(data, cmap="Blues", vmin=0, vmax=0.7, aspect="auto")
ax.set_xticks(range(data.shape[1]), [str(c) for c in cohort.columns[1:13]])
ax.set_yticks(range(len(cohort)), [str(c) for c in cohort.index])
for i in range(data.shape[0]):
    for j in range(data.shape[1]):
        if not np.isnan(data[i, j]):
            ax.text(j, i, f"{data[i,j]:.0%}", ha="center", va="center", fontsize=7,
                    color="white" if data[i, j] > 0.4 else "black")
ax.set_xlabel("Months since signup"); ax.set_ylabel("Signup cohort"); ax.grid(False)
ax.set_title("Monthly-plan retention by signup cohort")
save(fig, "03_cohort_heatmap.png"); plt.show()

# %%
curve = pd.Series({k: (mon[mon.months_observable >= k].payments_made > k).mean() for k in range(0, 13)})
print("Pooled retention curve (monthly plan):")
print((curve * 100).round(1).to_string())
print(f"\nLargest single drop: month 0 -> 1, losing {1-curve[1]:.0%} of subscribers before their first renewal.")

# %% [markdown]
# Retention is fairly stable across cohorts, so there is no sign that a recent change broke anything. The big loss is
# **before the first renewal**: many users subscribe to get one document and leave. After month 3 the curve
# flattens. That shapes the strategy: **the first 30 days decide most of the outcome.**
#
# ## 2. Annual-plan renewals

# %%
ann = subs[(subs.plan == "annual") & (subs.start_ts + pd.DateOffset(years=1) <= AS_OF)].copy()
ann["renewed"] = ann.payments_made >= 2
ann["engaged"] = np.where(ann.docs_created_30d >= 2, "2+ docs in first 30 days", "0–1 docs in first 30 days")
print(f"Annual subscribers who reached their renewal date: {len(ann):,}")
print(f"Annual renewal rate: {ann.renewed.mean():.1%}")
print(ann.groupby("engaged").renewed.agg(["mean", "count"]).round(3).to_string())

# %% [markdown]
# ## 3. What predicts a monthly subscriber's first renewal?
# Logistic regression on subscribers whose first renewal date has passed. The coefficients are reported as
# **odds ratios**. This shows *association*, not causation: engaged users may differ in ways we don't observe.

# %%
m1 = mon[mon.months_observable >= 1].copy()
m1["renewed_once"] = (m1.payments_made >= 2).astype(int)
m1["engaged"] = (m1.docs_created_30d >= 2).astype(int)
model = smf.logit("renewed_once ~ engaged + C(device, Treatment('desktop')) + C(channel, Treatment('organic_search'))",
                  data=m1).fit(disp=False)
summary = pd.DataFrame({"odds_ratio": np.exp(model.params), "p_value": model.pvalues,
                        "ci_low": np.exp(model.conf_int()[0]), "ci_high": np.exp(model.conf_int()[1])}).drop("Intercept")
summary.index = summary.index.str.replace(r"C\((\w+), Treatment\('\w+'\)\)\[T\.", r"\1=", regex=True).str.rstrip("]")
print(summary.round(3).to_string())
print(f"\nFirst-renewal rate: engaged {m1[m1.engaged==1].renewed_once.mean():.1%} vs "
      f"not engaged {m1[m1.engaged==0].renewed_once.mean():.1%}  (n={len(m1):,})")

# %%
fig, ax = plt.subplots(figsize=(8, 4.2))
s = summary.sort_values("odds_ratio")
colors = [PALETTE["primary"] if p < 0.05 else PALETTE["muted"] for p in s.p_value]
ax.errorbar(s.odds_ratio, range(len(s)), xerr=[s.odds_ratio - s.ci_low, s.ci_high - s.odds_ratio],
            fmt="none", ecolor=PALETTE["muted"], capsize=3)
ax.scatter(s.odds_ratio, range(len(s)), color=colors, zorder=3, s=45)
ax.axvline(1, color="black", lw=0.8); ax.set_yticks(range(len(s)), s.index)
ax.set_xlabel("Odds ratio for renewing (95% CI); blue = p < 0.05")
ax.set_title("Drivers of first renewal (monthly plan)")
save(fig, "03_renewal_drivers.png"); plt.show()

# %% [markdown]
# Creating **two or more documents in the first 30 days** is by far the strongest predictor of renewal. Mobile
# subscribers renew less often even after controlling for engagement. Acquisition channel matters little once a user
# has paid. Only "direct" reaches p < 0.05, and with seven channel and device comparisons in the model, one modest
# hit like that could easily be chance. I'd want to see it replicate before acting on it.
#
# ## 4. Challenging an assumption: are annual plans really worth more?
# The Project 1 experiment used "annual-plan share must not drop" as a guardrail, on the belief that annual
# subscribers are more valuable. The retention curve lets us test that belief with expected first-year revenue per
# new subscriber.

# %%
price_m, price_a = 39.99, 95.88
exp_payments_12m = curve.loc[0:11].sum()   # expected monthly payments in the first 12 months
rev_m, rev_a = exp_payments_12m * price_m, price_a
print(f"Expected first-year payments per new monthly subscriber: {exp_payments_12m:.2f}")
print(f"Expected first-year revenue: monthly ${rev_m:,.2f} vs annual ${rev_a:,.2f}  "
      f"(monthly worth {rev_m/rev_a:.1f}x in year one)")
print(f"Annual year-two value including renewals: ${price_a * (1 + ann.renewed.mean()):,.2f} over two years")

# %% [markdown]
# **The assumption doesn't hold at current prices.** Annual subscribers are more engaged and churn less, but the
# annual price equals about 2.4 months of the monthly plan. A typical monthly subscriber pays for over 5 months in
# year one, so a monthly signup is worth roughly twice an annual signup in first-year revenue. Two consequences:
# * The Project 1 guardrail should be **expected 12-month revenue per paywall viewer**, not annual-plan share.
#   Shifting users toward annual could *lose* revenue.
# * Annual pricing is a question for the Product Owner and finance team: the annual discount may be deeper than it
#   needs to be.
#
# ## 5. Customer segmentation (k-means)
# Segment all subscribers on tenure, payments, documents created, and lifetime revenue.

# %%
ltv = q("SELECT user_id, SUM(amount) AS lifetime_revenue FROM payments GROUP BY user_id", con)
seg = subs.merge(ltv, on="user_id")
seg["tenure_months"] = ((seg.end_ts.fillna(AS_OF) - seg.start_ts).dt.days / 30.44).round(1)
seg["active"] = seg.end_ts.isna().astype(int)
seg["is_annual"] = (seg.plan == "annual").astype(int)
features = ["tenure_months", "payments_made", "docs_created_30d", "lifetime_revenue", "is_annual"]
X = StandardScaler().fit_transform(seg[features])
scores = {k: silhouette_score(X, KMeans(k, n_init=10, random_state=0).fit_predict(X), sample_size=4000, random_state=0)
          for k in range(3, 7)}
print("Silhouette score by k:", {k: round(v, 3) for k, v in scores.items()})
k_best = max(scores, key=scores.get)
seg["cluster"] = KMeans(k_best, n_init=10, random_state=0).fit_predict(X)
profile = seg.groupby("cluster").agg(customers=("user_id", "count"), annual_share=("is_annual", "mean"),
                                     avg_tenure_months=("tenure_months", "mean"), avg_docs_30d=("docs_created_30d", "mean"),
                                     avg_lifetime_revenue=("lifetime_revenue", "mean"), still_active=("active", "mean"),
                                     mobile_share=("device", lambda d: (d == "mobile").mean()))
profile["revenue_share"] = seg.groupby("cluster").lifetime_revenue.sum() / seg.lifetime_revenue.sum()
print(f"\nChosen k = {k_best}")
print(profile.round(2).sort_values("avg_lifetime_revenue", ascending=False).to_string())

# %% [markdown]
# **Naming the segments.** The cluster numbers are arbitrary; the profiles above are what matter. Naming is done
# programmatically below so the labels stay correct if the clusters are re-run.

# %%
def name(r):
    if r.annual_share > 0.5:
        return "Annual planners" if r.still_active > 0.5 else "Lapsed annual"
    if r.avg_tenure_months >= 6:
        return "Loyal monthly"
    return "One-and-done" if r.avg_docs_30d < 2 else "Short-term multi-doc"
profile["segment"] = profile.apply(name, axis=1)
seg["segment"] = seg.cluster.map(profile.segment)
summary_seg = profile.groupby("segment").agg(customers=("customers", "sum"), revenue_share=("revenue_share", "sum"),
                                            avg_lifetime_revenue=("avg_lifetime_revenue", "mean"),
                                            still_active=("still_active", "mean"), avg_docs_30d=("avg_docs_30d", "mean"))
summary_seg["customer_share"] = summary_seg.customers / summary_seg.customers.sum()
print(summary_seg.sort_values("revenue_share", ascending=False).round(3).to_string())

# %%
fig, ax = plt.subplots(figsize=(8.5, 4.2))
ss = summary_seg.sort_values("revenue_share")
y = np.arange(len(ss)); h = 0.38
ax.barh(y - h/2, ss.customer_share, h, color=PALETTE["muted"], label="share of customers")
ax.barh(y + h/2, ss.revenue_share, h, color=PALETTE["primary"], label="share of revenue")
ax.set_yticks(y, ss.index); ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.0%}")); ax.legend()
ax.set_title("Customer segments: share of customers vs share of revenue")
save(fig, "03_segments.png"); plt.show()

# %% [markdown]
# ## 6. Recommendations
# 1. **Win the first 30 days.** Since a second document is the strongest renewal signal, test an onboarding nudge
#    that suggests a relevant second document right after the first download (for example lease agreement → notice
#    to vacate). Primary metric: share of new subscribers creating 2+ documents in 30 days. Secondary: first-renewal
#    rate. The regression is correlational, so an experiment is needed to show the nudge *causes* more renewals.
# 2. **Protect Loyal monthly subscribers.** They are about 14% of customers but over 40% of lifetime revenue. Track
#    early signs of disengagement (no documents in 60 days) and test re-engagement prompts.
# 3. **Be honest with One-and-done users.** Nearly half of all subscribers create one or two documents and leave
#    within a few months. A clear one-time purchase option may convert better and reduce refund and chargeback
#    requests. Test it against the subscription default, measuring 12-month revenue per paywall viewer.
# 4. **Replace the annual-share guardrail** with expected 12-month revenue, and raise annual pricing with the
#    Product Owner (section 4).
# 5. **Investigate mobile retention.** Mobile subscribers renew less even at equal engagement. Pair this with the
#    mobile funnel findings (Project 2) for a single mobile experience workstream.

# %%
con.close()
