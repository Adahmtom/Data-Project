# 3 · Renewals, Retention Cohorts & Segmentation

**Questions:** How well do subscribers renew? What predicts renewal? Which segments should we target?

**Methods:** monthly cohort retention with right-censoring handled; annual renewal analysis; logistic regression
(odds ratios with CIs); k-means segmentation (k chosen by silhouette score); expected-revenue comparison.

**Findings**
- 35% of monthly subscribers leave before their first renewal; retention flattens after month 3.
- Creating **2+ documents in the first 30 days doubles the odds of renewing** (OR 2.0). Mobile subscribers renew
  less even at equal engagement.
- **Loyal monthly subscribers are ~14% of customers but ~43% of lifetime revenue.**
- **Challenged an assumption:** annual plans were treated as more valuable, but at current prices a new monthly
  subscriber is worth **~2.2× an annual one** in first-year revenue. This changes the guardrail metric for future
  paywall tests.

**Files:** `analysis.ipynb` · `analysis.py` · `figures/`
