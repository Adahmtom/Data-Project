# 2 · Conversion Funnel & Friction Analysis (SQL)

**Question:** Overall conversion is about 5%. Where do we lose people, and which fix is worth most?

**Methods:** six SQL queries in `sql/` (CTEs, multi-table joins, conditional aggregation, `LAG` and rolling window
functions), chi-square tests, and funnel-based opportunity sizing. Counts distinct visitors per step and uses
billing-confirmed purchases.

**Findings**
- Mobile form completion is **17 points lower** than desktop (47% vs 64%), and the gap is significant for every
  document type.
- Mobile users who finish the form take no longer than desktop users, so the gap is about abandonment, not speed.
- The *will* template has the lowest completion on both devices.
- Closing half the mobile form gap is worth **about +18% mobile purchases**.
- **Recommendation:** add field-level abandonment tracking first, then test save-and-resume on mobile.

**Files:** `sql/*.sql` · `analysis.ipynb` · `analysis.py` · `figures/`
