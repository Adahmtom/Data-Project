# %% [markdown]
# # Project 2 — Conversion Funnel & Friction Analysis (SQL)
#
# **Company:** FormWise, a *fictional* online legal-document subscription service (simulated data).
#
# **Business question.** "Our overall conversion is about 5%. Where are we losing people, and which fix is worth the most?"
#
# **Approach.** All metrics are computed in SQL (`sql/` folder) against the product database: joins across events,
# visitors, subscriptions and payments; conditional aggregation; CTEs; and window functions. Python is used only for
# charts and for statistics SQLite can't compute, such as medians.
#
# **Measurement choices**
# * Funnel steps count **distinct visitors**, not events, so duplicate events cannot inflate a step.
# * Purchases come from the **billing system** (`subscriptions`), not the front-end `purchase` event, which is
#   unreliable for one mobile app release (see Project 4).

# %%
import sys; sys.path.append("..")
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from scipy import stats
from shared.helpers import q, connect, style, save, PALETTE
style()
con = connect()
run = lambda name: q(f"sql/{name}.sql", con)

# %% [markdown]
# ## 1. The overall funnel

# %%
f = run("01_overall_funnel")
f["step_conversion"] = f.visitors / f.visitors.shift(1)
f["of_landing"] = f.visitors / f.visitors.iloc[0]
f["lost_at_step"] = f.visitors.shift(1) - f.visitors
print(f.round(4).to_string(index=False))

# %%
fig, ax = plt.subplots(figsize=(9, 4))
ax.barh(f.step[::-1], f.visitors[::-1], color=PALETTE["primary"])
for i, (n, pct) in enumerate(zip(f.visitors[::-1], f.of_landing[::-1])):
    ax.text(n + 1500, i, f"{n:,.0f}  ({pct:.1%})", va="center")
ax.set_xlim(0, f.visitors.max() * 1.25); ax.set_xlabel("Distinct visitors")
ax.set_title("FormWise funnel, Jan 2025 – Jun 2026")
save(fig, "02_overall_funnel.png"); plt.show()

# %% [markdown]
# After the landing page, the funnel loses the most people at two steps: the **form** (template start → form complete)
# and the **paywall** (paywall view → purchase). Landing-page bounce is expected for search traffic, and the paywall
# is the subject of the Project 1 experiment, so this analysis focuses on the form step.
#
# ## 2. Funnel by device

# %%
d = run("02_funnel_by_device")
print(d.to_string(index=False))

# %%
steps = ["landing_to_start", "start_to_complete", "complete_to_paywall", "paywall_to_purchase"]
fig, ax = plt.subplots(figsize=(9, 4))
x = np.arange(len(steps)); w = 0.38
for i, dev in enumerate(["desktop", "mobile"]):
    vals = d.set_index("device").loc[dev, steps]
    ax.bar(x + (i - 0.5) * w, vals, w, label=dev, color=[PALETTE["primary"], PALETTE["accent"]][i])
ax.set_xticks(x, ["Landing → start", "Start → complete", "Complete → paywall", "Paywall → purchase"])
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.0%}")); ax.legend()
ax.set_title("Step conversion: desktop vs mobile")
save(fig, "02_step_conversion_by_device.png"); plt.show()

# %%
dd = d.set_index("device")
gap = dd.loc["desktop", "start_to_complete"] - dd.loc["mobile", "start_to_complete"]
print(f"Mobile form completion is {gap:.1%} points lower than desktop "
      f"({dd.loc['mobile','start_to_complete']:.1%} vs {dd.loc['desktop','start_to_complete']:.1%}).")

# %% [markdown]
# Mobile trails desktop at every step, but the **form step** is the largest gap. Before recommending a fix, check
# whether the gap is real or just noise, and whether it's the same for every document type.
#
# ## 3. Is the mobile form gap real, and where is it worst?

# %%
fc = run("03_form_completion_by_doc_and_device")
piv = fc.pivot(index="doc_type", columns="device", values="completion_rate")
piv["gap_pts"] = piv.desktop - piv.mobile
cnt = fc.pivot(index="doc_type", columns="device", values=["starters", "completers"])
pvals = []
for doc in piv.index:
    table = [[cnt.loc[doc, ("completers", dv)], cnt.loc[doc, ("starters", dv)] - cnt.loc[doc, ("completers", dv)]]
             for dv in ["desktop", "mobile"]]
    pvals.append(stats.chi2_contingency(table)[1])
piv["p_value"] = pvals
out = piv.sort_values("gap_pts", ascending=False).round(4)
out["p_value"] = out.p_value.map(lambda p: "<0.001" if p < 0.001 else f"{p:.3f}")
print(out.to_string())

# %%
fig, ax = plt.subplots(figsize=(9, 4.2))
order = piv.sort_values("mobile").index
y = np.arange(len(order))
ax.hlines(y, piv.loc[order, "mobile"], piv.loc[order, "desktop"], color=PALETTE["muted"], lw=3)
ax.scatter(piv.loc[order, "desktop"], y, color=PALETTE["primary"], s=60, label="desktop", zorder=3)
ax.scatter(piv.loc[order, "mobile"], y, color=PALETTE["accent"], s=60, label="mobile", zorder=3)
ax.set_yticks(y, [o.replace("_", " ") for o in order])
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.0%}")); ax.legend(loc="lower right")
ax.set_title("Form completion rate by document type and device")
save(fig, "02_form_completion_dumbbell.png"); plt.show()

# %% [markdown]
# The mobile gap is statistically significant for every document type, so it's a mobile form-experience problem,
# not a quirk of one template. Separately, the **will** template has the lowest completion on both devices,
# consistent with it being the longest form.
#
# ## 4. How long does the form take?

# %%
t = run("04_time_to_complete")
med = t.groupby(["doc_type", "device"]).minutes_to_complete.median().unstack().round(1)
print("Median minutes from template start to form complete:")
print(med.to_string())

# %% [markdown]
# Completion times are similar across devices. Mobile users who *finish* take no longer than desktop users, so the gap
# is about people abandoning, not people being slow. One hypothesis is that mobile sessions get interrupted and users
# can't easily return to a half-finished form. The current data can't confirm that. **Recommended next data:** add a `form_field_error` event and a
# `form_abandon_last_field` property to the tracking plan (Project 4) to pinpoint which field loses mobile users.
#
# ## 5. Trend and channel context

# %%
m = run("05_monthly_trend")
print(m.to_string(index=False))

# %%
fig, ax = plt.subplots(figsize=(9, 4))
ax.plot(m.month, m.conversion, marker="o", color=PALETTE["muted"], label="monthly")
ax.plot(m.month, m.conversion_3mo_avg, color=PALETTE["primary"], lw=2.5, label="3-month rolling average")
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.1%}")); ax.legend()
ax.set_xticks(m.month[::3]); ax.set_title("Visitor → purchase conversion by month")
save(fig, "02_monthly_conversion.png"); plt.show()

# %%
ch = run("06_channel_performance")
print(ch.to_string(index=False))

# %% [markdown]
# ## 6. Sizing the opportunity
# What would it be worth if mobile form completion closed **half** the gap to desktop, with every later step at its
# current mobile rate?

# %%
mob = dd.loc["mobile"]
months = m.shape[0]
monthly_mobile_visitors = mob.visitors / months
target_complete = mob.start_to_complete + gap / 2
base = monthly_mobile_visitors * mob.landing_to_start * mob.start_to_complete * mob.complete_to_paywall * mob.paywall_to_purchase
new = monthly_mobile_visitors * mob.landing_to_start * target_complete * mob.complete_to_paywall * mob.paywall_to_purchase
arpu = q("SELECT AVG(amount) AS a FROM payments WHERE payment_type='new'", con).a[0]
print(f"Mobile purchases per month now: {base:,.0f}")
print(f"With half the form gap closed:  {new:,.0f}  (+{new-base:,.0f}/month, +{new/base-1:.0%})")
print(f"Added first-payment revenue: ~${(new-base)*arpu:,.0f}/month, ~${(new-base)*arpu*12:,.0f}/year "
      f"(before renewals; average first payment ${arpu:.2f})")

# %% [markdown]
# ## 7. Recommendations
# 1. **Make the mobile form the top funnel priority.** It loses more mobile users than the paywall does, and the gap
#    to desktop is significant across every template.
# 2. **Instrument before redesigning.** Add field-level abandonment tracking so the fix targets the right fields.
# 3. **Test save-and-resume for mobile** to check the interruption hypothesis (e.g. emailing a link to finish later), starting with the **will**
#    template, which has the lowest completion overall.
# 4. **Report funnels on distinct visitors and billing-confirmed purchases**, not raw event counts.

# %%
con.close()
